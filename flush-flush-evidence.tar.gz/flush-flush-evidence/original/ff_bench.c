#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sched.h>
#include <x86intrin.h>

#define MIN(a, b) ((a) < (b) ? (a) : (b))

#define SampleSize 1000000
#define Hist_bins 600

static size_t array[5 *1024];

static size_t hit_hist[Hist_bins];
static size_t miss_hist[Hist_bins];

static inline uint64_t rdtsc_serial(void) {
    _mm_lfence();
    uint64_t r = __rdtsc();
    _mm_lfence();
    return r;
}

static inline void flush(void *p) {
    _mm_clflush(p);
}

static inline uint64_t rdtsc_start(void) {
    unsigned int aux;
    uint64_t r = __rdtscp(&aux);
    _mm_lfence();
    return r;
}

static inline uint64_t rdtsc_end(void) {
    _mm_lfence();
    unsigned int aux;
    return __rdtscp(&aux);
}

static inline void maccess(void *p) {
    (void)*(volatile uint8_t *)p;
}

static inline uint64_t measure_access_time(void *p) {
    uint64_t start = rdtsc_serial();
    maccess(p);
    return rdtsc_serial() - start;
}


static size_t flush_hit_time(void *p) {
    maccess(p);
    uint64_t start = rdtsc_start();
    flush(p);
    uint64_t end = rdtsc_end();
    return end - start;
}

static size_t flush_miss_time(void *p) {
    flush(p);
    uint64_t start = rdtsc_start();
    flush(p);
    uint64_t end = rdtsc_end();
    return end - start;
}

int main(void) {
    memset(array, -1, sizeof(array));
    void *target = &array[2 * 1024];
    maccess(target);
    sched_yield();

    for(int i = 0; i < SampleSize; i++) {
        size_t hit_time = flush_hit_time(target);
        hit_hist[MIN(Hist_bins - 1, hit_time)]++;
    }

    for(int i = 0; i < SampleSize; i++) {
        size_t miss_time = flush_miss_time(target);
        miss_hist[MIN(Hist_bins - 1, miss_time)]++;
    }

    size_t hit_max = 0;
    size_t hit_max_i = 0;
    size_t miss_max_i = 0;
    size_t miss_max = 0;

    for(int i = 0; i < Hist_bins; i++) {
       printf("%d %zu %zu\n", i, hit_hist[i], miss_hist[i]);
        if(hit_hist[i] > hit_max) {
            hit_max = hit_hist[i];
            hit_max_i = i;
        }
        if(miss_hist[i] > miss_max) {
            miss_max = miss_hist[i];
            miss_max_i = i;
        }
    }
    
    size_t min = (size_t)-1;
    size_t threshold = 0;
    int lo = hit_max_i < miss_max_i ? hit_max_i : miss_max_i;
    int hi = hit_max_i > miss_max_i ? hit_max_i : miss_max_i;
    for(int i = lo; i <= hi; i++){
        size_t combined = hit_hist[i] + miss_hist[i];
        if(combined < min){
            min = combined;
            threshold = i;
        }
    }

    printf("Suggested threshold: %zu cycles\n", threshold);
    printf("hit_max_i = %zu, hit_max = %zu\n", hit_max_i, hit_max);
    printf("miss_max_i = %zu, miss_max = %zu\n", miss_max_i, miss_max); 
    printf("lo=%d hi=%d\n", lo, hi);
    return 0;
}
